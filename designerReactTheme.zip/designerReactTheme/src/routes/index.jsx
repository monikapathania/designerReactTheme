import Dashboard from "layouts/Dashboard/Dashboard.jsx";

const indexRoutes = [{ path: "/", component: Dashboard }];

export default indexRoutes;
