// ##############################
// // // Tasks for TasksCard - see Dashboard view
// #############################

var bugs = [
  'It is a long established fact that a reader will be distracted by the readable?"',
  "There are many variations of passages of Lorem Ipsum available?",
  "All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary.",
  "it over 2000 years old."
];
var website = [
  "when an unknown printer took a galley of type and scrambled it to make a type specimen book.",
  'Lorem Ipsum is that it has a more-or-less normal distribution?"'
];
var server = [
  "Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley?",
  "There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form.",
  'Lorem Ipsum is simply dummy text of the printing and typesetting industry.?"'
];

module.exports = {
  // these 3 are used to create the tasks lists in TasksCard - Dashboard view
  bugs,
  website,
  server
};
